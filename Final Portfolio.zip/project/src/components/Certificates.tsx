import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const certificates = [
  {
    title: "Java Programming",
    image: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?auto=format&fit=crop&q=80&w=800",
    issuer: "Coursera"
  },
  {
    title: "Web Development",
    image: "https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&q=80&w=800",
    issuer: "Udemy"
  },
  // Add more certificates as needed
];

const Certificates = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="certificates" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-purple-900/10 to-transparent pointer-events-none"></div>
      <h2 className="text-3xl font-bold text-center mb-12">Certificates</h2>
      <div ref={ref} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {certificates.map((cert, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 50 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: index * 0.2 }}
            whileHover={{ scale: 1.05 }}
            className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-lg"
          >
            <div className="relative overflow-hidden aspect-video">
              <motion.img
                src={cert.image}
                alt={cert.title}
                className="w-full h-full object-cover"
                whileHover={{ scale: 1.2 }}
                transition={{ duration: 0.3 }}
              />
            </div>
            <div className="p-4">
              <h3 className="text-xl font-bold mb-2">{cert.title}</h3>
              <p className="text-gray-600 dark:text-gray-300">{cert.issuer}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Certificates;