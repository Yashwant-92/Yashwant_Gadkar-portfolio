import { Github, Linkedin, Mail, Twitter } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="min-h-screen py-20 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Let's Connect!</h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-semibold mb-6">Get in touch</h3>
            <form className="space-y-6">
              <div>
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full px-4 py-3 rounded-lg border dark:bg-gray-800 dark:border-gray-700"
                />
              </div>
              <div>
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full px-4 py-3 rounded-lg border dark:bg-gray-800 dark:border-gray-700"
                />
              </div>
              <div>
                <textarea
                  placeholder="Your Message"
                  rows={5}
                  className="w-full px-4 py-3 rounded-lg border dark:bg-gray-800 dark:border-gray-700"
                ></textarea>
              </div>
              <button className="bg-blue-500 text-white px-8 py-3 rounded-full hover:bg-blue-600 transition">
                Send Message
              </button>
            </form>
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold mb-6">Connect with me</h3>
            <div className="space-y-4">
              <a href="#" className="flex items-center gap-4 text-lg hover:text-blue-500">
                <Github className="w-6 h-6" />
                GitHub
              </a>
              <a href="#" className="flex items-center gap-4 text-lg hover:text-blue-500">
                <Linkedin className="w-6 h-6" />
                LinkedIn
              </a>
              <a href="#" className="flex items-center gap-4 text-lg hover:text-blue-500">
                <Twitter className="w-6 h-6" />
                Twitter
              </a>
              <a href="#" className="flex items-center gap-4 text-lg hover:text-blue-500">
                <Mail className="w-6 h-6" />
                Email
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;