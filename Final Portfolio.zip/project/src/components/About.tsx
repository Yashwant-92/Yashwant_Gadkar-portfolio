import { TypeAnimation } from 'react-type-animation';
import { motion } from 'framer-motion';
import { Mail } from 'lucide-react';

const About = () => {
  const copyEmail = async () => {
    await navigator.clipboard.writeText('yashwantgadkar@gmail.com');
    alert('Email copied to clipboard!');
  };

  return (
    <section id="about" className="min-h-screen flex items-center justify-center gap-20 py-20 relative">
      <div className="max-w-xl">
        <h1 className="text-4xl font-bold mb-4">Hi, I am Yashwant</h1>
        <TypeAnimation
          sequence={[
            'Web Developer',
            2000,
            'Full Stack Developer',
            2000,
            'AI Technophile',
            2000,
          ]}
          wrapper="div"
          speed={50}
          className="text-2xl bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-transparent bg-clip-text font-bold mb-6"
          repeat={Infinity}
        />
        <p className="text-lg mb-6 text-gray-700 dark:text-gray-300">
          I'm Yashwant Gadkar, Aspiring Software Developer with a strong Java, JavaScript, and web
          technologies foundation. Passionate about coding, problem-solving, and
          building efficient applications. Eager to learn and contribute to a dynamic
          development team while growing my technical expertise.
        </p>
        <div className="flex items-center gap-4 mb-6">
          <button onClick={copyEmail} className="flex items-center gap-2 text-blue-500 hover:text-blue-600">
            <Mail className="w-5 h-5" />
            <span>yashwantgadkar@gmail.com</span>
          </button>
        </div>
        <button className="bg-blue-500 text-white px-6 py-3 rounded-full hover:bg-blue-600 transition">
          Download Resume
        </button>
      </div>
      
      <motion.div
        animate={{
          scale: [1, 1.1, 1]
        }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="relative w-80 h-80 rounded-full overflow-hidden shadow-2xl"
      >
        <img
          src="https://images.unsplash.com/photo-1527980965255-d3b416303d12?auto=format&fit=crop&q=80&w=800"
          alt="Profile"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 border-4 border-blue-500 rounded-full" />
      </motion.div>
    </section>
  );
};

export default About;